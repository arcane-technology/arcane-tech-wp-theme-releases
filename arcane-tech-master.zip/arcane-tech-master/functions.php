<?php
/**
 * Theme functions — loader only.
 *
 * All functionality lives in inc/. This file handles only the update checker
 * (which requires __FILE__) and loads each module.
 *
 * @package ArcaneTechMaster
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'HELLO_ELEMENTOR_CHILD_VERSION', '3.1.0' );

// ── GitHub Auto-Updates ────────────────────────────────────────────────────────

require_once get_stylesheet_directory() . '/vendor/autoload.php';

$ats_update_checker = YahnisElsts\PluginUpdateChecker\v5p6\PucFactory::buildUpdateChecker(
	'https://github.com/arcane-technology/arcane-tech-wp-theme/',
	__FILE__,
	'arcane-tech-master'
);
$ats_update_checker->setBranch( 'main' );

if ( defined( 'ATS_GITHUB_TOKEN' ) ) {
	$ats_update_checker->setAuthentication( constant( 'ATS_GITHUB_TOKEN' ) );
}

// ── Front-end styles ───────────────────────────────────────────────────────────

add_action( 'wp_enqueue_scripts', function() {
	wp_enqueue_style(
		'hello-elementor-child-style',
		get_stylesheet_directory_uri() . '/style.css',
		[ 'hello-elementor-theme-style' ],
		HELLO_ELEMENTOR_CHILD_VERSION
	);
}, 20 );

// ── Modules ────────────────────────────────────────────────────────────────────

require_once get_stylesheet_directory() . '/inc/admin-branding.php';
require_once get_stylesheet_directory() . '/inc/login.php';
require_once get_stylesheet_directory() . '/inc/dashboard.php';
require_once get_stylesheet_directory() . '/inc/admin-menu.php';
require_once get_stylesheet_directory() . '/inc/support-page.php';
require_once get_stylesheet_directory() . '/inc/upsell.php';
require_once get_stylesheet_directory() . '/inc/notifications.php';
require_once get_stylesheet_directory() . '/inc/last-login.php';
