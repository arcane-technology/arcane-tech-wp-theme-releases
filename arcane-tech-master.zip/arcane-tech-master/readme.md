=== Arcane Tech Master Theme ===

Maintainer: Arcane Tech Solutions
Maintainer URI: https://arcanetechct.com
Requires at least: 5.9
Tested up to: 6.6
Stable tag: 3.0.0
Version: 3.0.0
Requires PHP: 7.4
License: Private — All Rights Reserved
License URI: https://arcanetechct.com

A branded WordPress child theme built and maintained by Arcane Tech Solutions for deployment across client websites.

== Description ==

The Arcane Tech Master Theme is a private child theme built on top of Hello Elementor. It is developed and maintained by Arcane Tech Solutions and deployed to client websites managed by the agency.

The theme provides a consistent, branded WordPress admin experience across all client sites, including:

* Custom admin colour scheme reflecting Arcane Tech branding
* Branded login page with gradient background, agency logo, and quick-access links
* Replaced WordPress admin bar logo with Arcane Tech branding
* Custom dashboard support widget with agency contact details
* Branded admin footer replacing default WordPress attribution
* Favicon fallback using the Arcane Tech icon when no site icon is set
* Wider admin sidebar (200px) for improved readability

The front-end layer is intentionally minimal, deferring to Elementor for all design and layout work on a per-site basis.

== Maintained By ==

Arcane Tech Solutions
Website Design & Hosting
https://arcanetechct.com
support@arcanetechct.com

== Installation ==

This theme is intended for use on sites managed by Arcane Tech Solutions.

1. Upload the theme folder to /wp-content/themes/
2. Activate via Appearance > Themes
3. Ensure the Hello Elementor parent theme is also installed and active
4. Place client-specific assets (logo, icon) in the /images/ directory

== Auto-Updates ==

This theme includes a built-in update checker. When the theme is updated on GitHub, client sites will receive an update notification in Appearance > Themes — no plugin required.

The theme repo is private. To enable updates on a client site, add the following to wp-config.php:

    define( 'ATS_GITHUB_TOKEN', 'your_github_token_here' );

To generate a token:
1. Go to GitHub > Settings > Developer settings > Personal access tokens > Fine-grained tokens
2. Set repository access to arcane-technology/arcane-tech-wp-theme
3. Grant read-only access to Contents
4. Copy the token into wp-config.php as shown above

If the repo is ever made public, this step is not required — the update checker will work without a token.

== File Structure ==

arcane-tech-master/
  css/
    ats-admin.css       — Admin area styles (menu, bar, dashboard widget)
    ats-login.css       — Login page styles
  images/
    ats-logo.png        — Full Arcane Tech logo (used on login page and dashboard)
    ats-logo_white.png  — White version of the logo for dark backgrounds
    ats-icon.png        — Icon only, used for admin bar and favicon fallback
  functions.php         — All theme functionality
  style.css             — Theme declaration and front-end styles

== Changelog ==

= 3.0.0 =
* Full rebrand to Arcane Tech Master Theme
* Custom admin colour scheme
* Branded login page with gradient, logo, tagline, and footer links
* Admin bar logo replacement
* Dashboard widget with support contact details
* Admin footer branding
* Favicon fallback
* Wider admin sidebar (200px)
* All styles extracted to external CSS files
* Built-in auto-update checker via GitHub (supports public and private repos)

= 2.0.0 - 2023-04-27 =
* Base Hello Elementor Child Theme (upstream)

= 1.0.0 - 2019-05-23 =
* Initial Hello Elementor Child public release (upstream)
