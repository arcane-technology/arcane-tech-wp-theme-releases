<?php
/**
 * Custom user notification emails — branded, friendly, generic.
 *
 * @package ArcaneTechMaster
 */

if ( ! defined( 'ABSPATH' ) ) exit;

add_filter( 'wp_new_user_notification_email', function( $email, $user, $blogname ) {

	// Extract the password reset URL WordPress already generated
	preg_match( '/https?:\/\/\S+action=rp\S+/', $email['message'], $matches );
	$reset_url = $matches[0] ?? network_site_url( 'wp-login.php' );

	$site_url    = home_url();
	$support_url = 'https://support.arcanetechct.com';
	$logo_id     = get_theme_mod( 'custom_logo' );
	$logo_url    = $logo_id
		? wp_get_attachment_image_url( $logo_id, 'medium' )
		: 'https://cdn.arcanetechsolutions.com/ats-logo_new_white_transparent.png';

	$email['subject'] = sprintf( "You've been added to %s", $blogname );
	$email['headers'] = [ 'Content-Type: text/html; charset=UTF-8' ];
	$email['message'] = ats_welcome_email_html( $user, $blogname, $site_url, $reset_url, $support_url, $logo_url );

	return $email;

}, 10, 3 );


function ats_welcome_email_html( $user, $blogname, $site_url, $reset_url, $support_url, $logo_url ) {
	$first_name = ! empty( $user->first_name ) ? $user->first_name : $user->display_name;
	ob_start();
	?>
<!DOCTYPE html>
<html lang="en">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"></head>
<body style="margin:0;padding:0;background:#f0f0f0;font-family:Arial,sans-serif;">

<table width="100%" cellpadding="0" cellspacing="0" style="background:#f0f0f0;padding:40px 20px;">
<tr><td align="center">
<table width="100%" cellpadding="0" cellspacing="0" style="max-width:580px;">

	<!-- Header -->
	<tr><td style="background:#1a1a1a;border-radius:4px 4px 0 0;padding:28px 40px;text-align:center;">
		<img src="<?php echo esc_url( $logo_url ); ?>" alt="Arcane Tech Solutions" width="180" style="display:block;margin:0 auto;" />
	</td></tr>

	<!-- Body -->
	<tr><td style="background:#ffffff;padding:40px;border-radius:0 0 4px 4px;">

		<p style="margin:0 0 18px;font-size:17px;font-weight:bold;color:#1d2327;">
			Hi <?php echo esc_html( $first_name ); ?>,
		</p>

		<p style="margin:0 0 14px;font-size:14px;color:#444;line-height:1.6;">
			You've been given access to <a href="<?php echo esc_url( $site_url ); ?>" style="color:#850b1a;text-decoration:none;"><?php echo esc_html( $blogname ); ?></a>.
			You can use your account to log in and manage the site's content.
		</p>

		<p style="margin:0 0 28px;font-size:14px;color:#444;line-height:1.6;">
			Click the button below to set your password and get started.
			This link expires in 24 hours.
		</p>

		<!-- CTA Button -->
		<table cellpadding="0" cellspacing="0" style="margin:0 0 32px;">
		<tr><td style="background:#850b1a;border-radius:3px;">
			<a href="<?php echo esc_url( $reset_url ); ?>" style="display:inline-block;padding:13px 28px;color:#ffffff;font-size:14px;font-weight:bold;text-decoration:none;">
				Set Your Password &rarr;
			</a>
		</td></tr>
		</table>

		<p style="margin:0 0 6px;font-size:13px;color:#888;line-height:1.6;">
			If the button doesn't work, copy and paste this link into your browser:
		</p>
		<p style="margin:0 0 32px;font-size:12px;word-break:break-all;">
			<a href="<?php echo esc_url( $reset_url ); ?>" style="color:#850b1a;"><?php echo esc_url( $reset_url ); ?></a>
		</p>

		<hr style="border:none;border-top:1px solid #eee;margin:0 0 24px;" />

		<p style="margin:0;font-size:13px;color:#888;line-height:1.6;">
			Questions? We're always here to help.<br>
			Reach us at <a href="mailto:support@arcanetechct.com" style="color:#850b1a;text-decoration:none;">support@arcanetechct.com</a>
			or visit our <a href="<?php echo esc_url( $support_url ); ?>" style="color:#850b1a;text-decoration:none;">support portal</a>.
		</p>

	</td></tr>

	<!-- Footer -->
	<tr><td style="padding:20px 40px;text-align:center;">
		<p style="margin:0;font-size:11px;color:#aaa;">
			This email was sent by Arcane Tech Solutions on behalf of <?php echo esc_html( $blogname ); ?>.<br>
			<a href="https://arcanetechct.com" style="color:#aaa;">arcanetechct.com</a>
		</p>
	</td></tr>

</table>
</td></tr>
</table>

</body>
</html>
	<?php
	return ob_get_clean();
}
