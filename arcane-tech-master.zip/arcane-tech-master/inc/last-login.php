<?php
/**
 * Last login tracker — stores last login time per user, shows in Users table.
 *
 * @package ArcaneTechMaster
 */

if ( ! defined( 'ABSPATH' ) ) exit;

// ── Record login time ─────────────────────────────────────────────────────────

add_action( 'wp_login', function( $user_login, $user ) {
	update_user_meta( $user->ID, 'ats_last_login', current_time( 'timestamp' ) );
}, 10, 2 );


// ── Add column to Users table ─────────────────────────────────────────────────

add_filter( 'manage_users_columns', function( $columns ) {
	$columns['ats_last_login'] = 'Last Login';
	return $columns;
} );

add_filter( 'manage_users_custom_column', function( $output, $column, $user_id ) {
	if ( 'ats_last_login' !== $column ) return $output;

	$timestamp = get_user_meta( $user_id, 'ats_last_login', true );

	if ( ! $timestamp ) {
		return '<span style="color:#aaa;">Never</span>';
	}

	$diff = human_time_diff( $timestamp, current_time( 'timestamp' ) );
	$date = date_i18n( 'j M Y, g:i a', $timestamp );

	return '<span title="' . esc_attr( $date ) . '">' . esc_html( $diff ) . ' ago</span>';
}, 10, 3 );


// ── Make column sortable ──────────────────────────────────────────────────────

add_filter( 'manage_users_sortable_columns', function( $columns ) {
	$columns['ats_last_login'] = 'ats_last_login';
	return $columns;
} );

add_action( 'pre_get_users', function( $query ) {
	if ( ! is_admin() ) return;
	if ( 'ats_last_login' !== $query->get( 'orderby' ) ) return;

	$query->set( 'meta_key', 'ats_last_login' );
	$query->set( 'orderby',  'meta_value_num' );
} );
