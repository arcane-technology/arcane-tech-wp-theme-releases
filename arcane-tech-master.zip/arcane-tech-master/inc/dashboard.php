<?php
/**
 * Dashboard: remove default WP widgets, add branded overview + support widgets.
 *
 * @package ArcaneTechMaster
 */

if ( ! defined( 'ABSPATH' ) ) exit;

// ── Feed cache refresh ─────────────────────────────────────────────────────────

function ats_maybe_refresh_feed() {
	if ( ! current_user_can( 'administrator' ) ) return;
	if ( empty( $_GET['ats_refresh_feed'] ) ) return;
	check_admin_referer( 'ats_refresh_feed' );

	delete_transient( 'ats_news_v7' );

	wp_safe_redirect( admin_url( 'index.php' ) );
	exit;
}
add_action( 'admin_init', 'ats_maybe_refresh_feed' );


function ats_dashboard_setup() {
	// Remove default widgets
	remove_meta_box( 'dashboard_primary',       'dashboard', 'side' );
	remove_meta_box( 'dashboard_quick_press',   'dashboard', 'side' );
	remove_meta_box( 'dashboard_activity',      'dashboard', 'normal' );
	remove_meta_box( 'dashboard_site_health',   'dashboard', 'normal' );
	remove_meta_box( 'dashboard_right_now',     'dashboard', 'normal' ); // At a Glance
	remove_meta_box( 'e-dashboard-overview',    'dashboard', 'normal' ); // Elementor
	remove_action( 'welcome_panel', 'wp_welcome_panel' );

	// Branded overview — full-width, top
	wp_add_dashboard_widget(
		'ats_overview_widget',
		'Site Overview',
		'ats_overview_widget_render',
		null, null, 'normal', 'high'
	);

	// Site Snapshot — replaces At a Glance
	wp_add_dashboard_widget(
		'ats_snapshot_widget',
		'Site Snapshot',
		'ats_snapshot_widget_render',
		null, null, 'normal', 'high'
	);

	// Arcane Tech news feed — main column
	wp_add_dashboard_widget(
		'ats_news_widget',
		'Latest from Arcane Tech',
		'ats_news_widget_render',
		null, null, 'normal', 'low'
	);

	// Support contact — sidebar
	wp_add_dashboard_widget(
		'ats_support_widget',
		'Arcane Tech — Support',
		'ats_support_widget_render',
		null, null, 'side', 'high'
	);
}
add_action( 'wp_dashboard_setup', 'ats_dashboard_setup' );


function ats_overview_widget_render() {
	$site_name = get_bloginfo( 'name' );
	$site_url  = home_url();
	?>
	<div class="ats-overview">
		<div class="ats-overview__header">
			<h2>You're managing <a href="<?php echo esc_url( $site_url ); ?>" target="_blank"><?php echo esc_html( $site_name ); ?></a></h2>
		</div>
		<div class="ats-overview__actions">
			<p class="ats-actions-label">Quick Actions</p>
			<div class="ats-quick-actions">
				<a href="<?php echo esc_url( $site_url ); ?>" target="_blank" class="ats-action-btn">
					<span class="dashicons dashicons-visibility"></span> View Site
				</a>
				<a href="<?php echo esc_url( admin_url( 'post-new.php' ) ); ?>" class="ats-action-btn">
					<span class="dashicons dashicons-edit"></span> New Blog Post
				</a>
				<a href="<?php echo esc_url( admin_url( 'upload.php' ) ); ?>" class="ats-action-btn">
					<span class="dashicons dashicons-admin-media"></span> Files &amp; Images
				</a>
				<a href="<?php echo esc_url( admin_url( 'users.php' ) ); ?>" class="ats-action-btn">
					<span class="dashicons dashicons-admin-users"></span> Users
				</a>
			</div>
		</div>
	</div>
	<?php
}


function ats_support_widget_render() {
	$logo_url = 'https://cdn.arcanetechsolutions.com/LogoWideTransparent.png'; #get_stylesheet_directory_uri() . '/images/ats-logo.png';
	?>
	<div class="ats-support-widget">
		<img src="<?php echo esc_url( $logo_url ); ?>" alt="Arcane Tech Solutions" />
		<p class="ats-support-cta">Need help with your website?</p>
		<div class="ats-support-actions">
			<a href="mailto:support@arcanetechct.com" class="button button-primary">Email Support</a>
			<a href="https://support.arcanetechct.com" target="_blank" class="button">Support Portal</a>
		</div>
		<p class="ats-support-link"><a href="https://arcanetechct.com" target="_blank">arcanetechct.com</a></p>
	</div>
	<?php
}


function ats_fetch_news_items() {
	$cached = get_transient( 'ats_news_v7' );
	
	if ( false !== $cached ) return $cached;
	// Append timestamp to bypass Cloudflare's edge cache on fetch
	$feed_url = 'https://arcanetechsolutions.com/feed/?_=' . time();
	$response = wp_remote_get( $feed_url, [ 'timeout' => 10 ] );
	if ( is_wp_error( $response ) ) return [];

	$body = wp_remote_retrieve_body( $response );
	if ( empty( $body ) ) return [];

	preg_match_all( '/<item>(.*?)<\/item>/si', $body, $item_blocks );
	if ( empty( $item_blocks[1] ) ) return [];

	$items = [];
	foreach ( $item_blocks[1] as $block ) {
		// Pull CDATA description (plain excerpt) and full content:encoded (full HTML)
		preg_match( '/<description>\s*<!\[CDATA\[(.*?)\]\]>\s*<\/description>/si', $block, $desc_match );
		$description = $desc_match[1] ?? '';

		// Image: media:thumbnail tag added to feed via rss2_item hook
		preg_match( '/<media:thumbnail[^>]+url=["\']([^"\']+)["\']/', $block, $img_match );
		$image = $img_match[1] ?? '';

		// Title (CDATA or plain)
		preg_match( '/<title>(?:<!\[CDATA\[)?(.*?)(?:\]\]>)?<\/title>/si', $block, $title_match );
		$title = trim( $title_match[1] ?? '' );

		// URL — <link> in RSS sits between two tags; grab text after <link>
		preg_match( '/<link>(https?[^<]+)<\/link>/i', $block, $url_match );
		$url = trim( $url_match[1] ?? '' );

		// Date
		preg_match( '/<pubDate>(.*?)<\/pubDate>/si', $block, $date_match );
		$date = ! empty( $date_match[1] ) ? date_i18n( 'j M Y', strtotime( $date_match[1] ) ) : '';

		// Excerpt: strip tags, collapse whitespace, cap at 100 chars
		$excerpt = preg_replace( '/\s+/', ' ', trim( wp_strip_all_tags( $description ) ) );
		if ( mb_strlen( $excerpt ) > 100 ) {
			$excerpt = mb_substr( $excerpt, 0, 100 ) . '…';
		}

		if ( ! $title || ! $url ) continue;

		$items[] = compact( 'title', 'url', 'date', 'image', 'excerpt' );

		if ( count( $items ) >= 5 ) break;
	}

	set_transient( 'ats_news_v7', $items, 12 * HOUR_IN_SECONDS );
	return $items;
}


function ats_snapshot_widget_render() {
	$post_count    = wp_count_posts( 'post' );
	$page_count    = wp_count_posts( 'page' );
	$published_posts = (int) ( $post_count->publish ?? 0 );
	$published_pages = (int) ( $page_count->publish ?? 0 );

	// Last modified post or page
	$last_modified = get_posts( [
		'post_type'      => [ 'post', 'page' ],
		'post_status'    => 'publish',
		'numberposts'    => 1,
		'orderby'        => 'modified',
		'order'          => 'DESC',
	] );
	$last_updated = ! empty( $last_modified )
		? sprintf(
			'<a href="%s">%s</a>',
			esc_url( get_edit_post_link( $last_modified[0]->ID ) ),
			esc_html( get_the_title( $last_modified[0]->ID ) )
		) . ' &mdash; ' . esc_html( date_i18n( 'j M Y', strtotime( $last_modified[0]->post_modified ) ) )
		: '—';

	// Pending comments
	$comment_counts  = wp_count_comments();
	$pending_comments = (int) $comment_counts->moderated;

	?>
	<div class="ats-snapshot">

		<div class="ats-snapshot__counts">
			<a href="<?php echo esc_url( admin_url( 'edit.php' ) ); ?>" class="ats-snapshot__count">
				<span class="ats-snapshot__count-num"><?php echo esc_html( number_format_i18n( $published_posts ) ); ?></span>
				<span class="ats-snapshot__count-lbl">Blog Article<?php echo 1 !== $published_posts ? 's' : ''; ?></span>
			</a>
			<a href="<?php echo esc_url( admin_url( 'edit.php?post_type=page' ) ); ?>" class="ats-snapshot__count">
				<span class="ats-snapshot__count-num"><?php echo esc_html( number_format_i18n( $published_pages ) ); ?></span>
				<span class="ats-snapshot__count-lbl">Page<?php echo 1 !== $published_pages ? 's' : ''; ?></span>
			</a>
		</div>

		<?php if ( $pending_comments > 0 ) : ?>
		<div class="ats-snapshot__row ats-snapshot__row--alert">
			<span class="dashicons dashicons-flag"></span>
			<a href="<?php echo esc_url( admin_url( 'edit-comments.php?comment_status=moderated' ) ); ?>">
				<?php echo esc_html( number_format_i18n( $pending_comments ) ); ?> comment<?php echo 1 !== $pending_comments ? 's' : ''; ?> awaiting review
			</a>
		</div>
		<?php endif; ?>

		<div class="ats-snapshot__row">
			<span class="dashicons dashicons-update"></span>
			<span>Last updated: <?php echo $last_updated; ?></span>
		</div>

		<?php if ( current_user_can( 'administrator' ) ) :
			$active_plugins = count( get_option( 'active_plugins', [] ) );
		?>
		<div class="ats-snapshot__meta">
			<span>WordPress <?php echo esc_html( get_bloginfo( 'version' ) ); ?></span>
			<span>PHP <?php echo esc_html( PHP_MAJOR_VERSION . '.' . PHP_MINOR_VERSION ); ?></span>
			<a href="<?php echo esc_url( admin_url( 'plugins.php' ) ); ?>"><?php echo esc_html( number_format_i18n( $active_plugins ) ); ?> plugin<?php echo 1 !== $active_plugins ? 's' : ''; ?> active</a>
		</div>
		<?php endif; ?>

	</div>
	<?php
}


function ats_news_widget_render() {
	$items = ats_fetch_news_items();

if ( empty( $items ) ) {
		echo '<p>Unable to load news feed at this time.</p>';
		return;
	}
	?>
	<ul class="ats-news-feed">
		<?php foreach ( $items as $item ) : ?>
			<li class="ats-news-item">
				<?php if ( $item['image'] ) : ?>
					<a href="<?php echo esc_url( $item['url'] ); ?>" target="_blank" rel="noopener" class="ats-news-thumb" tabindex="-1" aria-hidden="true">
						<img src="<?php echo esc_url( $item['image'] ); ?>" alt="" />
					</a>
				<?php endif; ?>
				<div class="ats-news-body">
					<a href="<?php echo esc_url( $item['url'] ); ?>" target="_blank" rel="noopener" class="ats-news-title">
						<?php echo esc_html( $item['title'] ); ?>
					</a>
					<?php if ( $item['excerpt'] ) : ?>
						<p class="ats-news-excerpt"><?php echo esc_html( $item['excerpt'] ); ?></p>
					<?php endif; ?>
					<span class="ats-news-date"><?php echo esc_html( $item['date'] ); ?></span>
				</div>
			</li>
		<?php endforeach; ?>
	</ul>
	<p class="ats-news-more">
		<a href="https://arcanetechsolutions.com/blog/" target="_blank" rel="noopener">View all posts →</a>
		<?php if ( current_user_can( 'administrator' ) ) :
			$refresh_url = wp_nonce_url( admin_url( 'index.php?ats_refresh_feed=1' ), 'ats_refresh_feed' );
		?>
			<a href="<?php echo esc_url( $refresh_url ); ?>" class="ats-news-refresh">↺ Refresh feed</a>
		<?php endif; ?>
	</p>
	<?php
}


function ats_enqueue_dashboard_styles( $hook ) {
	if ( 'index.php' !== $hook ) return;
	wp_enqueue_style( 'ats-dashboard', get_stylesheet_directory_uri() . '/css/ats-dashboard.css', [], HELLO_ELEMENTOR_CHILD_VERSION );
}
add_action( 'admin_enqueue_scripts', 'ats_enqueue_dashboard_styles' );
