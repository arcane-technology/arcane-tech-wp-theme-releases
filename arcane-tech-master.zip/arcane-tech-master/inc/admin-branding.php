<?php
/**
 * Admin branding: colour scheme, admin bar, footer, favicon, admin CSS.
 *
 * @package ArcaneTechMaster
 */

if ( ! defined( 'ABSPATH' ) ) exit;

// ── Colour Scheme ──────────────────────────────────────────────────────────────

function ats_register_color_scheme() {
	global $_wp_admin_css_colors;
	$_wp_admin_css_colors = [];

	wp_admin_css_color(
		'arcanetech',
		'Arcane Tech',
		get_stylesheet_directory_uri() . '/ats_wp_admin.css',
		[ '#3c3c3c', '#f2fcff', '#797b4a', '#850b1a' ]
	);
}
add_action( 'admin_init', 'ats_register_color_scheme' );

remove_action( 'admin_color_scheme_picker', 'admin_color_scheme_picker' );
add_filter( 'get_user_option_admin_color', fn() => 'arcanetech', 5 );


// ── Admin Bar Logo ─────────────────────────────────────────────────────────────

function ats_admin_bar_logo( $wp_admin_bar ) {
	$icon_url = get_stylesheet_directory_uri() . '/images/ats-icon.png';
	$wp_admin_bar->remove_node( 'wp-logo' );
	$wp_admin_bar->add_node( [
		'id'    => 'ats-logo',
		'title' => '<img src="' . esc_url( $icon_url ) . '" alt="Arcane Tech" />',
		'href'  => 'https://arcanetechct.com',
		'meta'  => [ 'target' => '_blank', 'title' => 'Arcane Tech | Web Design & Hosting' ],
	] );
}
add_action( 'admin_bar_menu', 'ats_admin_bar_logo', 11 );


// ── Environment badge ──────────────────────────────────────────────────────────

add_action( 'admin_bar_menu', function( $wp_admin_bar ) {
	$env = wp_get_environment_type();
	if ( 'production' === $env ) return;

	$labels = [
		'staging'     => [ 'label' => 'Staging',     'color' => '#b45309' ],
		'development' => [ 'label' => 'Development',  'color' => '#1d4ed8' ],
		'local'       => [ 'label' => 'Local',        'color' => '#6d28d9' ],
	];

	$cfg = $labels[ $env ] ?? [ 'label' => ucfirst( $env ), 'color' => '#555' ];

	$wp_admin_bar->add_node( [
		'id'     => 'ats-env-badge',
		'parent' => 'top-secondary',
		'title'  => '<span style="
			display:inline-block;
			padding:2px 10px;
			background:' . $cfg['color'] . ';
			color:#fff;
			border-radius:3px;
			font-size:11px;
			font-weight:600;
			letter-spacing:0.05em;
			text-transform:uppercase;
			line-height:20px;
			margin-top:7px;
		">' . esc_html( $cfg['label'] ) . '</span>',
		'meta'   => [ 'title' => 'Environment: ' . esc_attr( $cfg['label'] ) ],
	] );
}, 999 );


// ── Hide update nags from non-admins ───────────────────────────────────────────

if ( ! current_user_can( 'administrator' ) ) {
	add_filter( 'pre_site_transient_update_core',    '__return_null' );
	add_filter( 'pre_site_transient_update_plugins', '__return_null' );
	add_filter( 'pre_site_transient_update_themes',  '__return_null' );
	add_action( 'admin_menu', function() {
		remove_submenu_page( 'index.php', 'update-core.php' );
	} );
}


// ── Remove "Howdy" ─────────────────────────────────────────────────────────────

add_filter( 'gettext', function( $translated, $original ) {
	if ( str_starts_with( $original, 'Howdy, %s' ) ) {
		return 'Welcome, %s';
	}
	return $translated;
}, 10, 2 );


// ── Admin Footer ───────────────────────────────────────────────────────────────

add_filter( 'admin_footer_text', fn() => 'Managed by <a href="https://arcanetechct.com" target="_blank">Arcane Tech | Web Design & Hosting</a>' );
add_filter( 'update_footer', '__return_empty_string', 11 );


// ── Favicon Fallback ───────────────────────────────────────────────────────────

add_filter( 'site_icon_url', function( $url, $size, $blog_id ) {
	if ( empty( $url ) ) {
		$url = get_stylesheet_directory_uri() . '/images/ats-icon.png';
	}
	return $url;
}, 10, 3 );


// ── Admin Styles ───────────────────────────────────────────────────────────────

function ats_enqueue_admin_styles() {
	wp_enqueue_style( 'ats-admin', get_stylesheet_directory_uri() . '/css/ats-admin.css', [], HELLO_ELEMENTOR_CHILD_VERSION );
}
add_action( 'admin_enqueue_scripts', 'ats_enqueue_admin_styles' );
add_action( 'wp_enqueue_scripts', 'ats_enqueue_admin_styles' ); // admin bar on frontend
