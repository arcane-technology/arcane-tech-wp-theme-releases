<?php
/**
 * Admin menu: rename items to plain language, hide advanced items for non-admins.
 *
 * @package ArcaneTechMaster
 */

if ( ! defined( 'ABSPATH' ) ) exit;

// ── Rename top-level and submenu items ─────────────────────────────────────────

function ats_rename_menu_items() {
	global $menu, $submenu;

	// Top-level renames  [ menu position => new label ]
	$top_level = [
		5  => 'Blog Articles',  // Posts
		10 => 'Files & Images', // Media
		60 => 'Design',         // Appearance
	];

	foreach ( $top_level as $position => $label ) {
		if ( isset( $menu[ $position ] ) ) {
			$menu[ $position ][0] = $label;
		}
	}

	// Submenu renames under Posts
	if ( isset( $submenu['edit.php'] ) ) {
		foreach ( $submenu['edit.php'] as &$item ) {
			if ( $item[2] === 'edit.php' )     $item[0] = 'All Articles';
			if ( $item[2] === 'post-new.php' ) $item[0] = 'Add New Article';
		}
		unset( $item );
	}
}
add_action( 'admin_menu', 'ats_rename_menu_items', 999 );


// ── Hide advanced items for non-administrators ─────────────────────────────────

function ats_cleanup_menu() {
	if ( current_user_can( 'administrator' ) ) return;

	remove_menu_page( 'tools.php' );
	remove_menu_page( 'edit-comments.php' );

	// Strip technical Settings sub-pages clients don't need
	remove_submenu_page( 'options-general.php', 'options-writing.php' );
	remove_submenu_page( 'options-general.php', 'options-reading.php' );
	remove_submenu_page( 'options-general.php', 'options-discussion.php' );
	remove_submenu_page( 'options-general.php', 'options-permalink.php' );
}
add_action( 'admin_menu', 'ats_cleanup_menu', 999 );
