<?php
/**
 * Login page branding: styles, logo link, tagline, footer links.
 *
 * @package ArcaneTechMaster
 */

if ( ! defined( 'ABSPATH' ) ) exit;

add_action( 'login_enqueue_scripts', function() {
	wp_enqueue_style( 'ats-login', get_stylesheet_directory_uri() . '/css/ats-login.css', [], HELLO_ELEMENTOR_CHILD_VERSION );
} );

add_filter( 'login_headerurl',  fn() => home_url() );
add_filter( 'login_headertext', fn() => get_bloginfo( 'name' ) );
add_filter( 'login_message',    fn() => '<p class="ats-login-tagline">Sign in to manage ' . esc_html( get_bloginfo( 'name' ) ) . '</p>' );

function ats_login_footer_links() { ?>
	<div class="ats-login-links">
		<a href="https://portal.arcanetechct.com" target="_blank">Client Portal</a>
		<a href="https://arcanetechct.com" target="_blank">Website</a>
		<a href="https://app.arcanemail.net" target="_blank">Webmail</a>
		<a href="https://support.arcanetechct.com" target="_blank">Support</a>
	</div>
<?php }
add_action( 'login_footer', 'ats_login_footer_links' );
