<?php
/**
 * Upsell notices — contextual, dismissible, admin-only.
 *
 * @package ArcaneTechMaster
 */

if ( ! defined( 'ABSPATH' ) ) exit;

// ── Helpers ──────────────────────────────────────────────────────────────────

function ats_is_free_email( $email ) {
	$free = [
		'gmail.com', 'googlemail.com',
		'yahoo.com', 'yahoo.co.uk', 'yahoo.ca',
		'hotmail.com', 'hotmail.co.uk',
		'outlook.com', 'live.com', 'live.co.uk',
		'icloud.com', 'me.com', 'mac.com',
		'aol.com', 'msn.com',
	];
	$domain = strtolower( ltrim( strrchr( $email, '@' ), '@' ) );
	return in_array( $domain, $free, true );
}

// ── Dismissal handler ────────────────────────────────────────────────────────

function ats_handle_upsell_dismiss() {
	if ( empty( $_GET['ats_dismiss_upsell'] ) ) return;
	check_admin_referer( 'ats_dismiss_upsell' );
	update_user_meta( get_current_user_id(), 'ats_email_upsell_dismissed', 1 );
	wp_safe_redirect( remove_query_arg( [ 'ats_dismiss_upsell', '_wpnonce' ] ) );
	exit;
}
add_action( 'admin_init', 'ats_handle_upsell_dismiss' );

// ── Notice ───────────────────────────────────────────────────────────────────

function ats_email_upsell_notice() {
	if ( ! current_user_can( 'administrator' ) ) return;
	if ( get_user_meta( get_current_user_id(), 'ats_email_upsell_dismissed', true ) ) return;

	$screen = get_current_screen();
	if ( ! in_array( $screen->id ?? '', [ 'dashboard', 'toplevel_page_ats-support' ], true ) ) return;

	$user = wp_get_current_user();
	if ( ! ats_is_free_email( $user->user_email ) ) return;

	$host        = wp_parse_url( home_url(), PHP_URL_HOST );
	$dismiss_url = wp_nonce_url( add_query_arg( 'ats_dismiss_upsell', '1' ), 'ats_dismiss_upsell' );
	$current_domain   = explode( '.', ltrim( strrchr( $user->user_email, '@' ), '@' ) )[0];
	$provider_map     = [
		'gmail'   => 'Gmail',
		'yahoo'   => 'Yahoo',
		'hotmail' => 'Hotmail',
		'outlook' => 'Outlook',
		'icloud'  => 'iCloud',
		'aol'     => 'AOL',
		'msn'     => 'MSN',
		'live'    => 'Outlook',
		'me'      => 'iCloud',
		'mac'     => 'iCloud',
	];
	$provider_label   = $provider_map[ $current_domain ] ?? ucfirst( $current_domain );
	$contact_url      = add_query_arg( [
		'utm_source'   => 'wp-admin',
		'utm_medium'   => 'dashboard-notice',
		'utm_campaign' => 'business-email',
		'domain'       => $current_domain,
		'provider'     => $provider_label,
	], 'https://arcanetechsolutions.com/services/email/' );
	?>
	<div class="notice ats-upsell-notice">
		<p>
			<strong>Heads up:</strong> You're using a personal email address for this account.
			A professional address like <em>you@<?php echo esc_html( $host ); ?></em> builds trust with every email you send.
			<a href="<?php echo esc_url( $contact_url ); ?>" target="_blank" rel="noopener">Learn more about business email →</a>
		</p>
		<a href="<?php echo esc_url( $dismiss_url ); ?>" class="ats-upsell-notice__dismiss" aria-label="Dismiss this notice">&#x2715;</a>
	</div>
	<?php
}
add_action( 'admin_notices', 'ats_email_upsell_notice' );


function ats_upsell_notice_styles() {
	if ( ! current_user_can( 'administrator' ) ) return;
	if ( get_user_meta( get_current_user_id(), 'ats_email_upsell_dismissed', true ) ) return;
	?>
	<style>
		.ats-upsell-notice {
			position: relative;
			border-left-color: #850b1a;
			padding: 10px 40px 10px 14px;
		}
		.ats-upsell-notice p { margin: 0; font-size: 13px; }
		.ats-upsell-notice a { color: #850b1a; }
		.ats-upsell-notice__dismiss {
			position: absolute;
			top: 50%;
			right: 12px;
			transform: translateY(-50%);
			color: #aaa;
			text-decoration: none;
			font-size: 14px;
			line-height: 1;
		}
		.ats-upsell-notice__dismiss:hover { color: #850b1a; }
	</style>
	<?php
}
add_action( 'admin_head', 'ats_upsell_notice_styles' );
