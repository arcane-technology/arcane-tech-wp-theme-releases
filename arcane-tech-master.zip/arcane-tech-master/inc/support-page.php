<?php
/**
 * Arcane Tech support admin page — accessible by all logged-in users.
 *
 * @package ArcaneTechMaster
 */

if ( ! defined( 'ABSPATH' ) ) exit;

function ats_register_support_page() {
	add_menu_page(
		'Arcane Tech Support',
		'Arcane Tech',
		'read',
		'ats-support',
		'ats_render_support_page',
		'dashicons-sos',
		3
	);
}
add_action( 'admin_menu', 'ats_register_support_page' );


function ats_enqueue_support_styles( $hook ) {
	if ( 'toplevel_page_ats-support' !== $hook ) return;
	wp_enqueue_style( 'ats-support', get_stylesheet_directory_uri() . '/css/ats-support.css', [], HELLO_ELEMENTOR_CHILD_VERSION );
}
add_action( 'admin_enqueue_scripts', 'ats_enqueue_support_styles' );


function ats_render_support_page() {
	$logo_url = 'https://cdn.arcanetechsolutions.com/LogoWideTransparent.png'; #get_stylesheet_directory_uri() . '/images/ats-logo.png';
	?>
	<div class="wrap ats-support-page">

		<div class="ats-support-hero">
			<img src="<?php echo esc_url( $logo_url ); ?>" alt="Arcane Tech Solutions" />
			<h1>How can we help?</h1>
			<p>Your website is designed, built, and maintained by Arcane Tech Solutions. Get in touch any time.</p>
		</div>

		<div class="ats-support-cards">

			<div class="ats-card">
				<span class="dashicons dashicons-email-alt"></span>
				<h3>Email Support</h3>
				<p>Send us an email and we'll get back to you as soon as possible.</p>
				<a href="mailto:support@arcanetechct.com" class="button button-primary">support@arcanetechct.com</a>
			</div>

			<div class="ats-card">
				<span class="dashicons dashicons-tickets-alt"></span>
				<h3>Support Center</h3>
				<p>Log a ticket, track open requests, and view your support history.</p>
				<a href="https://support.arcanetechct.com" target="_blank" class="button button-primary">Open Support Portal</a>
			</div>

			<div class="ats-card">
				<span class="dashicons dashicons-admin-users"></span>
				<h3>Client Portal</h3>
				<p>Access invoices, documents, and your account information.</p>
				<a href="https://portal.arcanetechct.com" target="_blank" class="button button-primary">Open Client Portal</a>
			</div>

			<div class="ats-card">
				<span class="dashicons dashicons-email"></span>
				<h3>Webmail</h3>
				<p>Access your business email from any browser.</p>
				<a href="https://app.arcanemail.net" target="_blank" class="button button-primary">Open Webmail</a>
			</div>

		</div>

		<h2 class="ats-services-heading">More from Arcane Tech</h2>

		<div class="ats-support-cards ats-services-cards">

			<div class="ats-card ats-service-card">
				<span class="dashicons dashicons-awards"></span>
				<h3>Print Materials</h3>
				<p>Business cards, signage, banners, and branded materials — printed and shipped directly to you.</p>
				<a href="https://arcanetechsolutions.com/print-design/" target="_blank" class="button">Learn More</a>
			</div>

			<div class="ats-card ats-service-card">
				<span class="dashicons dashicons-email"></span>
				<h3>Business Email</h3>
				<p>Professional email at your own domain. Look credible and consistent with every message you send.</p>
				<a href="https://arcanetechsolutions.com/services/email/" target="_blank" class="button">Learn More</a>
			</div>

			<div class="ats-card ats-service-card">
				<span class="dashicons dashicons-chart-line"></span>
				<h3>Website Updates</h3>
				<p>Need new pages, content changes, or a fresh look? We're here for ongoing work, big or small.</p>
				<a href="mailto:contact@arcanetechct.com?subject=Website%20Update%20Request" class="button">Get in Touch</a>
			</div>

		</div>

		<div class="ats-support-footer">
			<p>Arcane Tech Solutions &nbsp;|&nbsp; <a href="https://arcanetechct.com" target="_blank">arcanetechct.com</a></p>
		</div>

	</div>
	<?php
}
